import sqlite3
from flask import Flask, redirect, render_template, request, url_for

app = Flask(__name__)

data = []

def veriAL():
    global data
    with sqlite3.connect('book.db') as con:
        cur = con.cursor()
        cur.execute("select * from tblBook")
        data = cur.fetchall()
        for i in data:
            print(i)

def veriEkle(title, author, year):
    with sqlite3.connect('book.db') as con:
        cur = con.cursor()
        cur.execute("insert into tblBook (booktitle, bookauthor, bookyear) values (?,?,?)", (title, author, year))
        con.commit()
        print("veriler eklendi")

def veriSil(id):
    with sqlite3.connect('book.db') as con:
        cur = con.cursor()
        cur.execute("delete from tblBook where id=?", (id,))
        con.commit()
        print("veriler silindi")

def veriGuncelle(id, title, author, year):
    with sqlite3.connect('book.db') as con:
        cur = con.cursor()
        cur.execute("update tblBook set booktitle=?, bookauthor=?, bookyear=? where id=?", (title, author, year, id))
        con.commit()
        print("veriler güncellendi")

@app.route("/index")
def index():
    books = [
        {'bookTitle': 'Cehenneme övgü'},
        {'bookTitle': 'Saatleri Ayarlama'}
    ]
    return render_template("index.html", books=books)


@app.route("/kitap")
def kitap():
    print("kitap")
    veriAL()
    return render_template("kitap.html", veri=data)

@app.route("/contact")
def contact():
    print("contact")
    return render_template("contact.html")

@app.route("/kitapekle", methods=['GET', 'POST'])
def kitapekle():
    print("kitapekle")
    if request.method == 'POST':
        bookTitle = request.form['booktitle']
        bookAuthor = request.form['bookAuthor']
        bookYear = request.form['bookYear']
        veriEkle(bookTitle, bookAuthor, bookYear)
        print("veriler kayıt edildi :", bookTitle, bookAuthor, bookYear)
    return render_template("kitapekle.html")

@app.route("/kitapsil/<string:id>")
def kitapsil(id):
    print("kitapsil silinecek id", id)
    veriSil(id)
    return redirect(url_for("kitap"))

@app.route("/kitapguncelle/<string:id>", methods=['GET', 'POST'])
def kitapguncelle(id):
    if request.method == "GET":
        print("guncellenecek id", id)
        guncellenecekVeri = []
        for d in data:
            if str(d[0]) == id:
                guncellenecekVeri = list(d)
                return render_template("kitapguncelle.html", veri=guncellenecekVeri)
    elif request.method == "POST":
        bookID = request.form['bookID']
        bookTitle = request.form['booktitle']
        bookAuthor = request.form['bookAuthor']
        bookYear = request.form['bookYear']
        veriGuncelle(bookID, bookTitle, bookAuthor, bookYear)
        return redirect(url_for("kitap"))

if __name__ == "__main__":
    app.run(debug=True)
